import { useEffect, useState } from "react";
import { useOrm } from "../../../hooks/use-orm";
import "../css/search-project.css";
import { type Options, type SingleValue } from "react-select";
import AsyncSelect from "react-select/async";
import { useTimesheet } from "../context";

export interface ProjectResult {
  id: number;
  name: string;
}

export interface Option {
  label: string;
  value: string;
}

function mapOptions(values: ProjectResult[]): Options<Option> {
  return values.map((val) => ({ label: val.name, value: String(val.id) }));
}

export function SearchProject() {
  const [projects, setProjects] = useState<Options<Option>>([]);
  const orm = useOrm();
  const ctx = useTimesheet();

  // Función de búsqueda centralizada
  const getProjects = async (val: string): Promise<ProjectResult[] | null> => {
    try {
      const values = await orm.call<ProjectResult[]>(
        "pkf.timesheet.project",
        "search_projects_by_user",
        [val],
        { limit: 10 },
      );
      return values;
    } catch (err) {
      console.error("Search error:", err);
      return [];
    }
  };

  const loadOptions = (
    value: string,
    callback: (options: Options<Option>) => void,
  ) => {
    setTimeout(async () => {
      const values = await getProjects(value);
      if (values) {
        callback(mapOptions(values));
      }
    }, 500);
  };

  const onOptionSelect = (option: SingleValue<Option>) => {
    ctx.setProjectId(Number(option?.value));
  };

  useEffect(() => {
    getProjects("").then((result) => result && setProjects(mapOptions(result)));
  }, []);

  return (
    <div>
      <label
        htmlFor="search-project"
        className="text-muted"
        style={{ fontSize: 14 }}
      >
        Selecciona Projecto
      </label>
      <AsyncSelect
        cacheOptions
        loadOptions={loadOptions}
        defaultOptions={projects}
        onChange={onOptionSelect}
      />
    </div>
  );
}
